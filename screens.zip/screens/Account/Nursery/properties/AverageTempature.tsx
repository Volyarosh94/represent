import React from 'react';
import {StyleSheet, Text, View, Image} from 'react-native';
import arrowLeft from '../../../../assets/images/nersery/arrowLeft.png';
import arrowRight from '../../../../assets/images/nersery/arrowRight.png';
import {COLORS} from '../../../../styles/Constants';
export const AverageTempature = () => {
  return (
    <View style={styles.container}>
      <View style={styles.header}>
        <View style={styles.headerContent}>
          <Image style={{width: 10.77, height: 18.86}} source={arrowLeft} />
          <View style={styles.headerWraper}>
            <Text style={styles.headerText}>24 hours - 1 day</Text>
            <Text style={styles.headerTextTime}>24 hours - 1 day</Text>
          </View>
          <Image style={{width: 10.77, height: 18.86}} source={arrowRight} />
        </View>
      </View>
    </View>
  );
};

const styles = StyleSheet.create({
  container: {
    paddingTop: 8,
    height: '100%',
    backgroundColor: '#272854',
  },
  header: {
    justifyContent: 'center',
    height: 55,
    borderBottomWidth: 1,
    borderBottomColor: '#292C62',
  },
  headerContent: {
    flexDirection: 'row',
    justifyContent: 'center',
    alignItems: 'center',
  },
  headerText: {
    color: '#CE9B51',
    fontSize: 13,
    fontFamily: 'AntagometricaBT-Bold',
  },
  headerTextTime: {
    color: COLORS.text,
  },
  headerWraper: {
    paddingHorizontal: 17.27,
    alignItems: 'center'
  },
});
