import React, { useCallback } from 'react';
import { components, OptionProps, ValueContainerProps } from 'react-select';
import { SelectComponentsConfig } from 'react-select/src/components';
import { GroupHeadingProps } from 'react-select/src/components/Group';

import { Checkbox } from '~/view/components/shared/inputs/checkbox';
import { SelectOption, SelectTab } from '~/view/components/shared/inputs/select';

import styles from './styles.scss';

interface Props {
  value: SelectOption<number>[];
  onChange: (option: SelectOption<number>[]) => void;
  options: { label: string; options: SelectOption<number>[] }[];
  name?: string;
}

const ValueContainer: React.FC<ValueContainerProps<SelectOption<number>, true>> = props => {
  const { selectProps, children } = props;

  const value = selectProps.value as SelectOption<number>[];

  const childrenArray = React.useMemo(() => {
    return React.Children.toArray(children);
  }, [children]);

  const labels = React.useMemo(() => {
    if (value && value.length > 0) {
      return value.map(item => item.label).join(',');
    }
    return '';
  }, [value]);

  return (
    <>
      {labels ? (
        <components.ValueContainer {...props}>
          <div
            style={{
              height: 20,
              display: 'flex',
              flexDirection: 'row',
              // width: '90%',
              overflow: 'hidden',
            }}
          >
            {labels}
            {childrenArray[childrenArray.length - 1]}
          </div>
        </components.ValueContainer>
      ) : (
        <components.ValueContainer {...props}>
          <p className={styles['placeholder']}>No property selected</p>
          {childrenArray[childrenArray.length - 1]}
        </components.ValueContainer>
      )}
    </>
  );
};

const Option: React.FC<OptionProps<SelectOption<number>, true>> = props => {
  const { label, selectProps, data } = props;

  // eslint-disable-next-line @typescript-eslint/no-explicit-any
  const selected = (selectProps.value as any[]).some(v => v.value === data.value);

  return (
    <components.Option {...props}>
      <div className={styles['option']}>
        <p className={styles['option__label']}>{label}</p>
        <Checkbox checked={selected} onClick={e => e.stopPropagation()} />
      </div>
    </components.Option>
  );
};

const GroupHeading: React.FC<
  GroupHeadingProps<SelectOption<number>, true> & { data: SelectOption<number> }
> = props => {
  const { selectProps, children, data } = props;
  const value = selectProps.value as SelectOption<number>[];
  const options = data.options as SelectOption<number>[];

  const selected = options.every(option => {
    return value.some(optionValue => optionValue.value === option.value);
  });

  const handleChange = useCallback(
    ({ target }: React.ChangeEvent<HTMLInputElement>) => {
      if (target.checked) {
        selectProps.onChange?.(selectProps.value?.concat(data.options), {
          action: 'select-option',
          option: undefined,
        });
      } else {
        const newOptions = value.filter(option => {
          return options.every(groupOption => groupOption.value !== option.value);
        });
        selectProps.onChange?.(newOptions, { action: 'select-option', option: undefined });
      }
    },
    [data.options, options, selectProps, value],
  );

  return (
    <div className={styles['select-container']}>
      <div className={styles['select-container__label']}>{children}</div>
      <Checkbox checked={selected} onClick={e => e.stopPropagation()} onChange={handleChange} />
    </div>
  );
};

const customComponents: SelectComponentsConfig<SelectOption<number>, true> = {
  GroupHeading,
  Option: Option as any,
  ValueContainer: ValueContainer as any,
};

export const PropertiesSelect: React.FC<Props> = ({ value, options, name, onChange }) => {
  const mappedValue = React.useMemo(() => {
    return value.map(item => item.value);
  }, [value]);

  return (
    <SelectTab
      name={name}
      isMulti
      value={mappedValue}
      onChange={(_: any, option: SelectOption<number>[]) => onChange(option)}
      options={options as any}
      components={customComponents}
    />
  );
};
